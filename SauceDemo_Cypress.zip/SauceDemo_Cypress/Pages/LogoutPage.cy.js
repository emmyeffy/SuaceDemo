// cypress/e2e/pages/LogoutPage.js
class LogoutPage {
  logout() {
    cy.get('.bm-burger-button').click();
    cy.get('#logout_sidebar_link').click();
  }

  verifyLogout() {
    cy.get('#login-button').should('be.visible');
  }
}
export default LogoutPage;
