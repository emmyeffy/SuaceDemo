// cypress/e2e/pages/InventoryPage.js
class InventoryPage {
  verifyInventoryList() {
    cy.get('.inventory_item').should('have.length.at.least', 1);
  }

  filterItems(option) {
    cy.get('.product_sort_container').select(option);
  }

  addItemToCart(itemName) {
    cy.contains('.inventory_item', itemName).find('.btn_inventory').click();
  }

  viewCart() {
    cy.get('.shopping_cart_link').click();
  }
}
export default InventoryPage;
