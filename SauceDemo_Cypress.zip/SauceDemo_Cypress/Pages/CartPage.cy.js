// cypress/e2e/pages/CartPage.js
class CartPage {
  verifyCartItem(itemName) {
    cy.contains('.cart_item', itemName).should('exist');
  }

  removeItemFromCart(itemName) {
    cy.contains('.cart_item', itemName).find('.cart_button').click();
  }

  proceedToCheckout() {
    cy.get('.checkout_button').click();
  }
}
export default CartPage;
