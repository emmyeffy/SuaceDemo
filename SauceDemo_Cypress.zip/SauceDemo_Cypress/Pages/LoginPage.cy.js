// cypress/e2e/pages/LoginPage.js
class LoginPage {
  visit() {
    cy.visit('https://www.saucedemo.com');
  }

  enterUsername(username) {
    cy.get('#user-name').type(username);
  }

  enterPassword(password) {
    cy.get('#password').type(password);
  }

  submit() {
    cy.get('#login-button').click();
  }

  verifyLogin() {
    cy.url().should('include', '/inventory.html');
  }
}
export default LoginPage;
