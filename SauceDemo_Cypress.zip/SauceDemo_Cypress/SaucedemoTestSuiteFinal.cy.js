
describe('Sauce Demo App - Checking Acceptance Criteria', () => {
  
  // Login function 
  function login() {
    // Visit the login page
    cy.visit('https://www.saucedemo.com');
    cy.get('#user-name').type('standard_user');
    cy.get('#password').type('secret_sauce');
    cy.get('#login-button').click();
    cy.url().should('include', '/inventory.html');
  }
  
  beforeEach(() => {
    // Visit the login page before each test
    login();
  });

  it('should allow the user to log in', () => {
    // Ensure login success by checking for product visibility
    //cy.url().should('include', '/inventory.html');
    cy.contains('Products').should('be.visible');
  });

  it('should display the inventory list', () => {
    //Login function will be called first

    // confirm inventory items are displayed
    cy.get('.inventory_item').should('have.length.greaterThan', 0);
  });

  it('should allow the user to filter the inventory', () => {
    //Login function will be called first

    // Filter by "Price (low to high)"
    cy.get('[data-test="product_sort_container"]').select('lohi');
    // Check first item price after filter
    cy.get('.inventory_item_price').first().should('contain', '$7.99'); 

    // Filter by "Price (high to low)"
    cy.get('[data-test="product_sort_container"]').select('hilo');
    // Check first item price after filter
    cy.get('.inventory_item_price').first().should('contain', '$49.99'); 

    // Filter by "Name (A to Z)"
    cy.get('[data-test="product_sort_container"]').select('az');
    // Check first item price after filter
    cy.get('.inventory_item_name').first().should('contain', 'Sauce Labs Backpack'); 

    // Filter by "Name (Z to A)"
    cy.get('[data-test="product_sort_container"]').select('za');
    // Check first item price after filter
    cy.get('.inventory_item_name').first().should('contain', 'Test.allTheThings() T-Shirt (Red)');
  });

  it('should allow the user to add a product to the cart', () => {
    //Login function will be called first

    // Add first item to the cart
    cy.get('.inventory_item').first().find('#add-to-cart-sauce-labs-backpack').click();

    // Verify item is in cart by checking the cart badge
    cy.get('.shopping_cart_badge').its('length').should('be.gte', 1);//This is because an item may have been added before now that is yet to be checked out
  });

  it('should allow the user to view the cart', () => {
     //Login function will be called first

    cy.get('.inventory_item').eq(0).find('#add-to-cart-sauce-labs-backpack').click();

    // Go to the cart page
    cy.get('.shopping_cart_link').click();

    // Verify the item in the cart considering that there may have been other items in the cart already
    cy.url().should('include', '/cart.html');
    cy.get('.cart_item').its('length').should('be.gte', 1);//This is because an item may have been added before now that is yet to be checked out

  });

  it('should allow the user to remove items from the cart', () => {
    // Log in first, add the next item to the cart so there are two and then remove the first item added to cart
    
    cy.get('.inventory_item').eq(1).find('#add-to-cart-sauce-labs-bike-light').click();

    // Go to the cart page
    cy.get('.shopping_cart_link').click();

    //To capture the current cart length before removing an item
    // First capture the original length
    cy.get('.cart_item').then(($items) => {
      const originalLength = $items.length;

    // Remove the first item from cart
    cy.get('#remove-sauce-labs-backpack').click();

    // Assert that the new length is less than the original
    cy.get('.cart_item').should('have.length.lessThan', originalLength);
    });

    // Verify cart is empty
    //cy.get('.cart_item').its('length').should('be.lte', 1);//Cart item length should be less 1
    //cy.get('.shopping_cart_badge').should('not.exist');
  });

  it('should allow the user to checkout', () => {
     //Login function will be called again
    
     //Add an item
    cy.get('.inventory_item').eq(0).find('#add-to-cart-sauce-labs-backpack').click();
    cy.get('.shopping_cart_link').click();

    // Start the checkout process
    cy.get('#checkout').click();

    // Enter checkout information
    cy.get('#first-name').type('Akintunde');
    cy.get('#last-name').type('Kayode');
    cy.get('#postal-code').type('100101');
    cy.get('#continue').click();

    // Verify checkout overview page
    cy.url().should('include', '/checkout-step-two.html');
    cy.get('.cart_item').should('have.length', 1);

    // Finish checkout
    cy.get('#finish').click();

    // Verify order confirmation
    cy.contains('Thank you for your order').should('be.visible');
  });

  it('should allow the user to log out', () => {
    // The app should be in a login state before logging out

    // Open the menu and log out
    cy.get('#react-burger-menu-btn').click();
    cy.get('#logout_sidebar_link').click();

    // Verify redirection to login page
    cy.url().should('include', '/');
    cy.get('#login-button').should('be.visible');
  });

  
});
