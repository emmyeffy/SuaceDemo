/// <reference types="cypress"/>

import LoginPage from '../Pages/LoginPage'; 
import InventoryPage from '../Pages/InventoryPage';
import CartPage from '../Pages/CartPage';
import CheckoutPage from '../Pages/CheckoutPage';
import LogoutPage from '../Pages/LogoutPage';

const loginPage = new LoginPage();
const inventoryPage = new InventoryPage();
const cartPage = new CartPage();
const checkoutPage = new CheckoutPage();
const logoutPage = new LogoutPage();

describe('SauceDemo Acceptance Criteria', () => {
  before(() => {
      cy.fixture('testLoginData').then(function(loginData){
      this.loginData= loginData
    });
    cy.fixture('userData').then((userData) => {
      this.userData = userData; // Save to test context
    });
  });
  beforeEach(() => {
    //Using a custom command here
    cy.validLogin(this.loginData.ValidUsername,this.loginData.ValidPassword)
  });

  it('User should be able to view the inventory list', () => {
    inventoryPage.verifyInventoryList();
  });

  it('User should be able to filter the page', () => {
    inventoryPage.filterItems('Name (A to Z)');
    inventoryPage.filterItems('Price (low to high)');
  });

  it('User should be able to add product to cart and view cart', () => {
    inventoryPage.addItemToCart('Sauce Labs Backpack');
    inventoryPage.viewCart();
    cartPage.verifyCartItem('Sauce Labs Backpack');
  });

  it('User should be able to remove items from the cart', () => {
    inventoryPage.addItemToCart('Sauce Labs Backpack');
    inventoryPage.viewCart();
    cartPage.verifyCartItem('Sauce Labs Backpack');
    cartPage.removeItemFromCart('Sauce Labs Backpack');
  });

  it('User should be able to checkout', () => {
    inventoryPage.addItemToCart('Sauce Labs Bike Light');
    inventoryPage.viewCart();
    cartPage.proceedToCheckout();
    checkoutPage.enterCheckoutInformation('John', 'Doe', '12345');
    checkoutPage.finishCheckout();
    checkoutPage.verifyCheckoutComplete();
  });

  it('User should be able to logout', () => {
    logoutPage.logout();
    logoutPage.verifyLogout();
  });
});
