/// <reference types="Cypress" />


describe('Sauce Demo Logout', () => {
  beforeEach(() => {
    // Visit the login page and log in before each test
    cy.visit('https://www.saucedemo.com/');
    cy.get('[data-test="username"]').type('standard_user');
    cy.get('[data-test="password"]').type('secret_sauce');
    cy.get('[data-test="login-button"]').click();

    // Verify login by checking if we're on the inventory page
    cy.url().should('include', '/inventory.html');
    cy.contains('Products').should('be.visible');
  });

  it('should log out successfully and redirect to the login page', () => {
    // Open the menu
    cy.get('#react-burger-menu-btn').click();

    // Click the logout button
    cy.get('#logout_sidebar_link').click();

    // Verify successful logout by checking if redirected to the login page
    cy.url().should('include', '/');
    cy.get('[data-test="login-button"]').should('be.visible');
  });
});

  