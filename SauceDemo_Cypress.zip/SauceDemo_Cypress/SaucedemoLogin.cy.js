// cypress/e2e/login.cy.js
import LoginPage from '../Pages/LoginPage';

const loginPage = new LoginPage();

describe('Sauce Demo Login', () => {
  beforeEach(() => {
    // Visit the Sauce Demo login page before each test
    cy.visit('https://www.saucedemo.com/');
  });

  it('should log in successfully with valid credentials', () => {
    // Enter valid username and password
    cy.get('[data-test="username"]').type('standard_user');
    cy.get('[data-test="password"]').type('secret_sauce');
    
    // Click the login button
    cy.get('[data-test="login-button"]').click();

    // Verify successful login by checking if redirected to the inventory page
    cy.url().should('include', '/inventory.html');
    cy.contains('Products').should('be.visible');
  });

  it('should show an error with an incorrect password', () => {
    // Enter valid username and incorrect password
    cy.get('[data-test="username"]').type('standard_user');
    cy.get('[data-test="password"]').type('wrong_password');
    
    // Click the login button
    cy.get('[data-test="login-button"]').click();

    // Verify error message is displayed
    cy.get('[data-test="error"]').should('contain', 'Username and password do not match');
  });

  it('should show an error with an empty username and password', () => {
    // Click the login button without entering username or password
    cy.get('[data-test="login-button"]').click();

    // Verify error message for empty fields is displayed
    cy.get('[data-test="error"]').should('contain', 'Username is required');
  });

  it('should show an error with an empty password', () => {
    // Enter username but leave password field empty
    cy.get('[data-test="username"]').type('standard_user');
    
    // Click the login button
    cy.get('[data-test="login-button"]').click();

    // Verify error message for empty password
    cy.get('[data-test="error"]').should('contain', 'Password is required');
  });
});
